# CineFlow AI Studio Pro — Projeto Android (Capacitor + GitHub Actions)

Este pacote contém o projeto completo pronto para gerar o arquivo **`app-debug.apk`** automaticamente no GitHub Actions em ~2 minutos.

## Passo a Passo para Gerar e Baixar o APK no Celular

1. Acesse o seu repositório no GitHub (ex.: `https://github.com/romulocristovao8-droid/IA-VIDEO`) ou crie um novo repositório chamado `CINEFLOW-APK`.
2. Extraia este arquivo `.zip` e envie os arquivos (`package.json`, `capacitor.config.json`, pasta `www/` com `index.html` e pasta `.github/workflows/build-android-apk.yml`) para a branch `main`.
3. Abra a aba **Actions** no GitHub e aguarde o workflow **Build CineFlow Android APK** ficar verde (~2 min).
4. Toque na execução concluída, role até **Artifacts** e baixe **`cineflow-ai-studio-pro-apk`**.
5. Extraia o `.zip` baixado no celular e toque em **`app-debug.apk`** para instalar.
